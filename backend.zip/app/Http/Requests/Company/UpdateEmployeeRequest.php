<?php

namespace App\Http\Requests\Company;

use App\Models\Company;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateEmployeeRequest extends FormRequest
{
    public function authorize(): bool
    {
        // Authentication, company_owner role, and employees.update permission
        // are enforced by the route middleware. Avoid performing a second
        // Spatie role check here because a stale permission guard can turn a
        // valid request into an uncaught GuardDoesNotMatch 500.
        return $this->user() instanceof Company;
    }

    public function rules(): array
    {
        $employee = $this->route('employee');

        return [
            'name' => ['sometimes', 'string', 'max:255'],
            'email' => [
                'sometimes',
                'string',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($employee),
            ],
            'password' => ['nullable', 'string', 'min:8', 'confirmed'],
            'template_id' => ['nullable', 'integer', 'exists:company_permission_templates,id'],
            'permissions' => ['nullable', 'array', 'min:1'],
            'permissions.*' => [
                'string',
                Rule::exists('permissions', 'name')->where(
                    fn ($query) => $query->where('guard_name', 'company')
                ),
            ],
            'role' => [
                'nullable',
                'string',
                Rule::in([
                    'company_hr',
                    'company_interviewer',
                    'company_recruiter',
                    'company_question_bank_manager',
                    'company_viewer',
                    'company_employee',
                ]),
            ],
            'is_active' => ['nullable', 'boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'email.unique' => 'هذا البريد مستخدم بالفعل',
            'password.min' => 'كلمة المرور يجب أن تكون 8 أحرف على الأقل',
            'password.confirmed' => 'تأكيد كلمة المرور غير متطابق',
            'template_id.exists' => 'القالب المحدد غير موجود',
            'permissions.*.exists' => 'الصلاحية المحددة غير موجودة ضمن صلاحيات الشركات',
            'role.in' => 'الدور المحدد غير صالح',
        ];
    }
}
