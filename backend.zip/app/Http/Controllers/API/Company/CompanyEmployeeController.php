<?php

namespace App\Http\Controllers\API\Company;

use App\Http\Controllers\Controller;
use App\Http\Requests\Company\CreateEmployeeRequest;
use App\Http\Requests\Company\UpdateEmployeeRequest;
use App\Http\Resources\Company\EmployeeResource;
use App\Http\Resources\Company\EmployeeLimitResource;
use App\Models\Company;
use App\Models\CompanyPermissionTemplate;
use App\Models\User;
use App\Services\CompanyEmployeeAccessService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Throwable;

class CompanyEmployeeController extends Controller
{
    private const OWNER_ONLY_PERMISSIONS = [
        'company.profile.view',
        'company.profile.update',
        'company.billing.view',
        'company.billing.select_plan',
        'company.billing.checkout',
        'company.billing.portal',
        'company.employees.view',
        'company.employees.create',
        'company.employees.update',
        'company.employees.delete',
    ];

    protected Company $company;

    // public function __construct()
    // {
    //     $this->middleware(function ($request, $next) {
    //         $this->company = $request->user();
    //         return $next($request);
    //     });
    // }

    /**
     * Get all employees for the company
     * GET /api/company/employees
     */
    public function index(Request $request): JsonResponse
    {
        /** @var Company $company */
        $company = $request->user();

        $employees = $company->employees()
            ->with('roles', 'permissions', 'companyPermissionTemplate')
            ->when($request->search, function ($query, $search) {
                return $query->where(function ($searchQuery) use ($search) {
                    $searchQuery->where('name', 'LIKE', "%{$search}%")
                        ->orWhere('email', 'LIKE', "%{$search}%");
                });
            })
            ->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 20));

        return response()->json([
            'success' => true,
            'data' => EmployeeResource::collection($employees),
            'meta' => [
                'current_page' => $employees->currentPage(),
                'total' => $employees->total(),
                'per_page' => $employees->perPage(),
                'limit_info' => $company->getEmployeeLimitInfo(),
            ],
        ]);
    }


/**
 * Create a new employee
 * POST /api/company/employees
 */
public function store(CreateEmployeeRequest $request): JsonResponse
{
    try {
        /** @var Company $company */
        $company = $request->user();

        if (!$company->canAddEmployee()) {
            $limitInfo = $company->getEmployeeLimitInfo();
            return response()->json([
                'success' => false,
                'message' => "Your plan ({$limitInfo['plan_name']}) allows maximum {$limitInfo['max_employees']} team members. Please upgrade to add more employees.",
                'data' => [
                    'limit_info' => $limitInfo,
                    'upgrade_suggestions' => $this->getUpgradeSuggestions($company),
                ],
            ], 403);
        }

        $permissionsToAssign = [];
        $template = null;

        if ($request->has('template_id') && $request->template_id) {
            $template = CompanyPermissionTemplate::where('company_id', $company->id)
                ->find($request->template_id);

            if (!$template) {
                return response()->json([
                    'success' => false,
                    'message' => 'Template not found for this company',
                ], 404);
            }

            $permissionsToAssign = $template->permissions;
        } elseif ($request->has('permissions') && is_array($request->permissions)) {
            $permissionsToAssign = $request->permissions;
        }

        // ✅ Create the user (employee)
        $employee = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'role' => 'user',
            'company_id' => $company->id,
            'is_company_employee' => true,
            'company_permission_template_id' => $template?->id,
            'is_active' => true,
        ]);

        // ✅ تحديث الـ Guard
        $employee->setGuardName();
        $employee->refresh();

        // Every employee gets a company-guard role. Specific permissions still
        // come from the selected template or the custom permission list.
        $roleName = $request->input('role', 'company_employee');
        $role = Role::where('name', $roleName)
            ->where('guard_name', 'company')
            ->where('name', '!=', 'company_owner')
            ->first();

        if ($role) {
            $employee->assignRole($role);
        }

        // Assign permissions using the company guard.
        if (!empty($permissionsToAssign)) {
            $permissions = Permission::whereIn('name', $permissionsToAssign)
                ->where('guard_name', 'company')
                ->whereNotIn('name', self::OWNER_ONLY_PERMISSIONS)
                ->get();

            if ($permissions->isNotEmpty()) {
                $employee->syncPermissions($permissions);
            }
        }

        $company->incrementEmployeeCount();

        return response()->json([
            'success' => true,
            'message' => 'Employee added successfully',
            'data' => [
                'employee' => new EmployeeResource(
                    $employee->load('roles', 'permissions', 'companyPermissionTemplate')
                ),
                'limit_info' => $company->getEmployeeLimitInfo(),
            ],
        ], 201);

    } catch (\Exception $e) {
        Log::error('Failed to create employee: ' . $e->getMessage(), [
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Failed to create employee: ' . $e->getMessage(),
        ], 500);
    }
}

/**
 * Show a specific employee
 * GET /api/company/employees/{employee}
 */
public function show(Request $request, User $employee): JsonResponse
{
    /** @var Company $company */
    $company = $request->user();

    if ($employee->company_id !== $company->id) {
        return response()->json([
            'success' => false,
            'message' => 'Employee not found in your company',
        ], 404);
    }

    $employee->load('roles', 'permissions', 'companyPermissionTemplate');

    return response()->json([
        'success' => true,
        'data' => new EmployeeResource($employee),
    ]);
}

/**
 * Update an employee
 * PUT /api/company/employees/{employee}
 */
public function update(UpdateEmployeeRequest $request, User $employee): JsonResponse
{
    try {
        /** @var Company $company */
        $company = $request->user();

        if ((int) $employee->company_id !== (int) $company->id) {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found in your company',
            ], 404);
        }

        if (! Schema::hasColumn('users', 'company_permission_template_id')) {
            return response()->json([
                'success' => false,
                'message' => 'Database schema is missing users.company_permission_template_id. Run the latest migrations, then retry.',
                'error_code' => 'COMPANY_EMPLOYEE_TEMPLATE_COLUMN_MISSING',
            ], 503);
        }

        $accessService = app(CompanyEmployeeAccessService::class);
        $permissionNames = null;
        $templateId = $employee->company_permission_template_id;

        if ($request->filled('template_id')) {
            $template = CompanyPermissionTemplate::query()
                ->where('company_id', $company->id)
                ->active()
                ->find($request->integer('template_id'));

            if (! $template) {
                return response()->json([
                    'success' => false,
                    'message' => 'Template not found or inactive for this company',
                ], 404);
            }

            $permissionNames = array_values(array_diff(
                (array) $template->permissions,
                self::OWNER_ONLY_PERMISSIONS
            ));
            $templateId = $template->id;
        } elseif ($request->has('permissions')) {
            $permissionNames = array_values(array_diff(
                (array) $request->input('permissions', []),
                self::OWNER_ONLY_PERMISSIONS
            ));
            $templateId = null;
        }

        DB::transaction(function () use (
            $request,
            $employee,
            $accessService,
            $permissionNames,
            $templateId
        ): void {
            $updateData = [];

            if ($request->has('name')) {
                $updateData['name'] = trim((string) $request->input('name'));
            }

            if ($request->has('email')) {
                $updateData['email'] = trim((string) $request->input('email'));
            }

            if ($request->filled('password')) {
                $updateData['password'] = Hash::make((string) $request->input('password'));
            }

            if ($request->has('is_active')) {
                $updateData['is_active'] = $request->boolean('is_active');
            }

            if ($permissionNames !== null) {
                $updateData['company_permission_template_id'] = $templateId;
            }

            if ($updateData !== []) {
                $employee->update($updateData);
            }

            if ($permissionNames !== null) {
                $accessService->syncPermissions($employee, $permissionNames);
            }

            if ($request->filled('role')) {
                $accessService->syncRole($employee, (string) $request->input('role'));
            }
        });

        app(\App\Services\CompanyActivityLogService::class)->success(
            $company,
            'company_employees',
            'update',
            "Updated company employee '{$employee->name}'",
            [
                'employee_id' => $employee->id,
                'employee_name' => $employee->name,
                'permission_template_id' => $templateId,
            ]
        );

        $employee->refresh();
        $employee->setGuardName();
        $employee->load('roles', 'permissions', 'companyPermissionTemplate');

        return response()->json([
            'success' => true,
            'message' => 'Employee updated successfully',
            'data' => new EmployeeResource($employee),
        ]);
    } catch (\InvalidArgumentException $e) {
        Log::warning('Invalid company employee permission update.', [
            'employee_id' => $employee->id ?? null,
            'company_id' => $request->user()?->id,
            'error' => $e->getMessage(),
        ]);

        return response()->json([
            'success' => false,
            'message' => $e->getMessage(),
            'error_code' => 'INVALID_COMPANY_EMPLOYEE_ACCESS',
        ], 422);
    } catch (Throwable $e) {
        Log::error('Failed to update employee.', [
            'employee_id' => $employee->id ?? null,
            'company_id' => $request->user()?->id,
            'error' => $e->getMessage(),
            'exception' => get_class($e),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString(),
        ]);

        return response()->json([
            'success' => false,
            'message' => config('app.debug')
                ? 'Failed to update employee: ' . $e->getMessage()
                : 'Failed to update employee. Check storage/logs/laravel.log for details.',
            'error_code' => 'COMPANY_EMPLOYEE_UPDATE_FAILED',
            'exception' => config('app.debug') ? get_class($e) : null,
            'file' => config('app.debug') ? $e->getFile() : null,
            'line' => config('app.debug') ? $e->getLine() : null,
        ], 500);
    }
}

/**
 * Delete an employee
 * DELETE /api/company/employees/{employee}
 */
public function destroy(Request $request, User $employee): JsonResponse
{
    try {
        /** @var Company $company */
        $company = $request->user();

        if ($employee->company_id !== $company->id) {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found in your company',
            ], 404);
        }

        $employeeName = $employee->name;

        app(CompanyEmployeeAccessService::class)->clear($employee);

        $employee->update([
            'company_id' => null,
            'company_permission_template_id' => null,
            'is_company_employee' => false,
            'is_active' => false,
        ]);

        $company->decrementEmployeeCount();

        app(\App\Services\CompanyActivityLogService::class)->success(
            $company,
            'company_employees',
            'delete',
            "Removed company employee '{$employeeName}'",
            [
                'employee_id' => $employee->id,
                'employee_name' => $employeeName,
            ]
        );

        return response()->json([
            'success' => true,
            'message' => "Employee '{$employeeName}' removed successfully",
            'data' => [
                'limit_info' => $company->getEmployeeLimitInfo(),
            ],
        ]);

    } catch (\Exception $e) {
        Log::error('Failed to delete employee: ' . $e->getMessage());

        return response()->json([
            'success' => false,
            'message' => 'Failed to delete employee: ' . $e->getMessage(),
        ], 500);
    }
}

/**
 * Toggle employee status (activate/deactivate)
 * POST /api/company/employees/{employee}/toggle
 */
public function toggleStatus(Request $request, User $employee): JsonResponse
{
    try {
        /** @var Company $company */
        $company = $request->user();

        if ($employee->company_id !== $company->id) {
            return response()->json([
                'success' => false,
                'message' => 'Employee not found in your company',
            ], 404);
        }

        $employee->update([
            'is_active' => !$employee->is_active,
        ]);

        $status = $employee->is_active ? 'activated' : 'deactivated';

        return response()->json([
            'success' => true,
            'message' => "Employee '{$employee->name}' has been {$status}",
            'data' => [
                'id' => $employee->id,
                'is_active' => $employee->is_active,
            ],
        ]);

    } catch (\Exception $e) {
        Log::error('Failed to toggle employee status: ' . $e->getMessage());

        return response()->json([
            'success' => false,
            'message' => 'Failed to toggle employee status: ' . $e->getMessage(),
        ], 500);
    }
}

    /**
     * Get employee limit information
     * GET /api/company/employee-limits
     */
    public function limits(Request $request): JsonResponse  // ✅ أضف $request
    {
        /** @var Company $company */
        $company = $request->user();  // ✅ استخدم $request->user()

        return response()->json([
            'success' => true,
            'data' => new EmployeeLimitResource($company->getEmployeeLimitInfo()),
        ]);
    }

    // ============================================================
    // ✅ Helper Methods
    // ============================================================

    /**
     * Get upgrade suggestions based on current plan
     */
    private function getUpgradeSuggestions(Company $company): array
    {
        $suggestions = [];
        $currentPlanSlug = $company->selectedPlan?->slug;

        $upgradePlans = [
            'starter' => [
                'slug' => 'growth',
                'name' => 'Growth',
                'price' => '$79/month',
                'max_employees' => 5,
            ],
            'growth' => [
                'slug' => 'business',
                'name' => 'Business',
                'price' => '$199/month',
                'max_employees' => 20,
            ],
            'business' => [
                'slug' => 'enterprise',
                'name' => 'Enterprise',
                'price' => 'Custom',
                'max_employees' => 'Unlimited',
            ],
        ];

        if ($currentPlanSlug && isset($upgradePlans[$currentPlanSlug])) {
            $suggestions[] = $upgradePlans[$currentPlanSlug];
        }

        return $suggestions;
    }
}
