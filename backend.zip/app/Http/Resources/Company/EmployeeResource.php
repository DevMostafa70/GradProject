<?php
// app/Http/Resources/Company/EmployeeResource.php

namespace App\Http\Resources\Company;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'is_active' => $this->is_active,
            'is_company_employee' => $this->is_company_employee,
            'roles' => $this->getRoleNames(),
            'permissions' => $this->getAllPermissions()->pluck('name'),
            'company_id' => $this->company_id,
            'permission_template_id' => $this->company_permission_template_id,
            'permission_template' => $this->whenLoaded('companyPermissionTemplate', function () {
                return [
                    'id' => $this->companyPermissionTemplate?->id,
                    'name' => $this->companyPermissionTemplate?->name,
                    'is_active' => $this->companyPermissionTemplate?->is_active,
                ];
            }),
            'created_at' => $this->created_at?->toISOString(),
            'updated_at' => $this->updated_at?->toISOString(),
        ];
    }
}
