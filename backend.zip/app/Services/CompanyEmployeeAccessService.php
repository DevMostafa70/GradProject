<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class CompanyEmployeeAccessService
{
    /**
     * Synchronize direct permissions without invoking Spatie's guard-sensitive
     * syncPermissions() method. This also removes legacy user-guard assignments.
     *
     * @return array<int, string>
     */
    public function syncPermissions(User $employee, array $permissionNames): array
    {
        $permissionNames = array_values(array_unique(array_filter(
            $permissionNames,
            static fn ($name) => is_string($name) && $name !== ''
        )));

        $permissions = Permission::query()
            ->where('guard_name', 'company')
            ->whereIn('name', $permissionNames)
            ->get(['id', 'name']);

        $foundNames = $permissions->pluck('name')->all();
        $missingNames = array_values(array_diff($permissionNames, $foundNames));

        if ($missingNames !== []) {
            throw new InvalidArgumentException(
                'Missing company-guard permissions: ' . implode(', ', $missingNames)
            );
        }

        $tableNames = config('permission.table_names');
        $columnNames = config('permission.column_names');
        $modelKey = $columnNames['model_morph_key'] ?? 'model_id';
        $pivotTable = $tableNames['model_has_permissions'] ?? 'model_has_permissions';

        DB::table($pivotTable)
            ->where('model_type', User::class)
            ->where($modelKey, $employee->getKey())
            ->delete();

        if ($permissions->isNotEmpty()) {
            $rows = $permissions->map(static fn (Permission $permission) => [
                'permission_id' => $permission->getKey(),
                'model_type' => User::class,
                $modelKey => $employee->getKey(),
            ])->all();

            DB::table($pivotTable)->insert($rows);
        }

        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $employee->unsetRelation('permissions');

        return $foundNames;
    }

    /**
     * Synchronize the company role directly, avoiding stale guard metadata.
     */
    public function syncRole(User $employee, string $roleName): string
    {
        $role = Role::query()
            ->where('name', $roleName)
            ->where('guard_name', 'company')
            ->where('name', '!=', 'company_owner')
            ->first();

        if (! $role) {
            throw new InvalidArgumentException("Invalid company employee role: {$roleName}");
        }

        $tableNames = config('permission.table_names');
        $columnNames = config('permission.column_names');
        $modelKey = $columnNames['model_morph_key'] ?? 'model_id';
        $pivotTable = $tableNames['model_has_roles'] ?? 'model_has_roles';

        DB::table($pivotTable)
            ->where('model_type', User::class)
            ->where($modelKey, $employee->getKey())
            ->delete();

        DB::table($pivotTable)->insert([
            'role_id' => $role->getKey(),
            'model_type' => User::class,
            $modelKey => $employee->getKey(),
        ]);

        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $employee->unsetRelation('roles');

        return $role->name;
    }

    public function clear(User $employee): void
    {
        $tableNames = config('permission.table_names');
        $columnNames = config('permission.column_names');
        $modelKey = $columnNames['model_morph_key'] ?? 'model_id';

        DB::table($tableNames['model_has_permissions'] ?? 'model_has_permissions')
            ->where('model_type', User::class)
            ->where($modelKey, $employee->getKey())
            ->delete();

        DB::table($tableNames['model_has_roles'] ?? 'model_has_roles')
            ->where('model_type', User::class)
            ->where($modelKey, $employee->getKey())
            ->delete();

        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $employee->unsetRelation('permissions');
        $employee->unsetRelation('roles');
    }
}
