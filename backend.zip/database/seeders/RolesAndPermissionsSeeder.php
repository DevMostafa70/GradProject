<?php
// database/seeders/RolesAndPermissionsSeeder.php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Support\AdminPermissionCatalog;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // ============================================================
        // 1. Admin Permissions (guard_name = admin)
        // ============================================================
        $adminPermissions = AdminPermissionCatalog::all();

        // ============================================================
        // 2. Company Permissions (guard_name = company) - للـ Company Owner
        // ============================================================
        $companyPermissionsForOwner = [
            'company.dashboard.view',
            'company.profile.view',
            'company.profile.update',
            'company.jobs.view',
            'company.jobs.create',
            'company.jobs.update',
            'company.jobs.delete',
            'company.jobs.close',
            'company.candidates.view',
            'company.candidates.invite',
            'company.candidates.update',
            'company.interviews.view',
            'company.results.view',
            'company.results.export',
            'company.question_bank.view',
            'company.question_bank.create',
            'company.question_bank.update',
            'company.question_bank.delete',
            'company.billing.view',
            'company.billing.select_plan',
            'company.billing.checkout',
            'company.billing.portal',
            'company.usage.view',
            'company.notifications.view',
            'company.employees.view',
            'company.employees.create',
            'company.employees.update',
            'company.employees.delete',
        ];

        // ============================================================
        // 4. User Permissions (guard_name = user)
        // ============================================================
        $userPermissions = [
            'user.dashboard.view',
            'user.profile.view',
            'user.profile.update',
            'user.interviews.view',
            'user.interviews.start',
            'user.interviews.resume',
            'user.interviews.complete',
            'user.answers.submit',
            'user.results.view',
            'user.resumes.view',
            'user.resumes.upload',
            'user.resumes.delete',
            'user.notifications.view',
        ];

        // ============================================================
        // 5. Create All Permissions
        // ============================================================

        // Admin Permissions
        foreach ($adminPermissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'admin',
            ]);
        }

        // Company Permissions (guard = company)
        foreach ($companyPermissionsForOwner as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'company',
            ]);
        }

        // User Permissions
        foreach ($userPermissions as $permission) {
            Permission::firstOrCreate([
                'name' => $permission,
                'guard_name' => 'user',
            ]);
        }

        $this->command->info('✅ All permissions created');

        // ============================================================
        // 6. Create Roles
        // ============================================================

        // Admin Roles
        $superAdminRole = Role::firstOrCreate([
            'name' => 'super_admin',
            'guard_name' => 'admin',
        ]);
        $superAdminRole->syncPermissions($adminPermissions);
        $this->command->info('✅ super_admin role created');

        $adminRole = Role::firstOrCreate([
            'name' => 'admin',
            'guard_name' => 'admin',
        ]);
        // Restricted admins receive direct/template permissions only.
        // Keeping this role empty prevents accidental privilege inheritance.
        $adminRole->syncPermissions([]);
        $this->command->info('✅ admin role created');

        // Company Roles
        $companyOwnerRole = Role::firstOrCreate([
            'name' => 'company_owner',
            'guard_name' => 'company',
        ]);
        $companyOwnerRole->syncPermissions($companyPermissionsForOwner);
        $this->command->info('✅ company_owner role created');

        // Company Employee Roles (guard = company)
        $hrRole = Role::firstOrCreate([
            'name' => 'company_hr',
            'guard_name' => 'company',
        ]);
        $hrRole->syncPermissions([
            'company.dashboard.view',
            'company.candidates.view',
            'company.candidates.invite',
            'company.candidates.update',
            'company.interviews.view',
            'company.results.view',
            'company.notifications.view',
        ]);
        $this->command->info('✅ company_hr role created');

        $interviewerRole = Role::firstOrCreate([
            'name' => 'company_interviewer',
            'guard_name' => 'company',
        ]);
        $interviewerRole->syncPermissions([
            'company.dashboard.view',
            'company.jobs.view',
            'company.candidates.view',
            'company.interviews.view',
            'company.results.view',
            'company.notifications.view',
        ]);
        $this->command->info('✅ company_interviewer role created');

        $recruiterRole = Role::firstOrCreate([
            'name' => 'company_recruiter',
            'guard_name' => 'company',
        ]);
        $recruiterRole->syncPermissions([
            'company.dashboard.view',
            'company.jobs.view',
            'company.candidates.view',
            'company.candidates.invite',
            'company.candidates.update',
            'company.interviews.view',
            'company.results.view',
            'company.notifications.view',
        ]);
        $this->command->info('✅ company_recruiter role created');

        $questionBankManagerRole = Role::firstOrCreate([
            'name' => 'company_question_bank_manager',
            'guard_name' => 'company',
        ]);
        $questionBankManagerRole->syncPermissions([
            'company.dashboard.view',
            'company.jobs.view',
            'company.question_bank.view',
            'company.question_bank.create',
            'company.question_bank.update',
            'company.question_bank.delete',
            'company.notifications.view',
        ]);
        $this->command->info('✅ company_question_bank_manager role created');

        $viewerRole = Role::firstOrCreate([
            'name' => 'company_viewer',
            'guard_name' => 'company',
        ]);
        $viewerRole->syncPermissions([
            'company.dashboard.view',
            'company.jobs.view',
            'company.candidates.view',
            'company.interviews.view',
            'company.results.view',
            'company.question_bank.view',
            'company.notifications.view',
        ]);
        $this->command->info('✅ company_viewer role created');

        $companyEmployeeRole = Role::firstOrCreate([
            'name' => 'company_employee',
            'guard_name' => 'company',
        ]);
        // Direct/template permissions are assigned per employee.
        $companyEmployeeRole->syncPermissions([]);
        $this->command->info('✅ company_employee role created');

        // User Role
        $regularUserRole = Role::firstOrCreate([
            'name' => 'regular_user',
            'guard_name' => 'user',
        ]);
        $regularUserRole->syncPermissions($userPermissions);
        $this->command->info('✅ regular_user role created');

        $this->command->info('🎉 Roles and Permissions seeded successfully!');
    }
}
