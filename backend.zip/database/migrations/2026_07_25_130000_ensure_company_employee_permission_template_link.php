<?php

use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // This migration intentionally repeats the column check from the older
        // hotfix. It repairs databases where that file was not copied, was
        // recorded manually, or was skipped while the application code was
        // already updated.
        if (! Schema::hasColumn('users', 'company_permission_template_id')) {
            Schema::table('users', function (Blueprint $table) {
                $table->unsignedBigInteger('company_permission_template_id')
                    ->nullable()
                    ->after('company_id');
                $table->index(
                    'company_permission_template_id',
                    'users_company_permission_template_id_index'
                );
            });
        }

        // Repair legacy direct permissions that were assigned with the user
        // guard. Company employees must use company-guard permissions.
        $employeeIds = DB::table('users')
            ->where('is_company_employee', true)
            ->whereNotNull('company_id')
            ->pluck('id');

        if ($employeeIds->isEmpty()) {
            return;
        }

        $legacyAssignments = DB::table('model_has_permissions as mhp')
            ->join('permissions as p', 'p.id', '=', 'mhp.permission_id')
            ->where('mhp.model_type', User::class)
            ->whereIn('mhp.model_id', $employeeIds)
            ->where('p.guard_name', 'user')
            ->where('p.name', 'like', 'company.%')
            ->select('mhp.permission_id', 'mhp.model_id', 'p.name')
            ->get();

        foreach ($legacyAssignments as $assignment) {
            $companyPermissionId = DB::table('permissions')
                ->where('name', $assignment->name)
                ->where('guard_name', 'company')
                ->value('id');

            if (! $companyPermissionId) {
                continue;
            }

            DB::table('model_has_permissions')->insertOrIgnore([
                'permission_id' => $companyPermissionId,
                'model_type' => User::class,
                'model_id' => $assignment->model_id,
            ]);

            DB::table('model_has_permissions')
                ->where('permission_id', $assignment->permission_id)
                ->where('model_type', User::class)
                ->where('model_id', $assignment->model_id)
                ->delete();
        }
    }

    public function down(): void
    {
        // Do not remove the column here. It may have been created by the older
        // migration and is now part of the application's required schema.
    }
};
