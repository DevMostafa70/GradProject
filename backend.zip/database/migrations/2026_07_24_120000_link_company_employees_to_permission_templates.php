<?php

use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('users', 'company_permission_template_id')) {
            Schema::table('users', function (Blueprint $table) {
                // The provided database dump uses MyISAM for
                // company_permission_templates, so a cross-engine foreign key
                // would fail. Keep an indexed logical relation instead.
                $table->unsignedBigInteger('company_permission_template_id')
                    ->nullable()
                    ->after('company_id');
                $table->index(
                    'company_permission_template_id',
                    'users_company_permission_template_id_index'
                );
            });
        }

        // Company employees use the company guard. Convert any legacy direct
        // permissions that were accidentally assigned from the user guard.
        $employees = DB::table('users')
            ->where('is_company_employee', true)
            ->pluck('id');

        if ($employees->isEmpty()) {
            return;
        }

        $legacyAssignments = DB::table('model_has_permissions as mhp')
            ->join('permissions as p', 'p.id', '=', 'mhp.permission_id')
            ->where('mhp.model_type', User::class)
            ->whereIn('mhp.model_id', $employees)
            ->where('p.guard_name', 'user')
            ->where('p.name', 'like', 'company.%')
            ->select('mhp.permission_id', 'mhp.model_id', 'p.name')
            ->get();

        foreach ($legacyAssignments as $assignment) {
            $companyPermissionId = DB::table('permissions')
                ->where('name', $assignment->name)
                ->where('guard_name', 'company')
                ->value('id');

            if (! $companyPermissionId) {
                // Keep the legacy assignment until the matching company-guard
                // permission exists. This prevents accidental permission loss.
                continue;
            }

            DB::table('model_has_permissions')->insertOrIgnore([
                'permission_id' => $companyPermissionId,
                'model_type' => User::class,
                'model_id' => $assignment->model_id,
            ]);

            DB::table('model_has_permissions')
                ->where('permission_id', $assignment->permission_id)
                ->where('model_type', User::class)
                ->where('model_id', $assignment->model_id)
                ->delete();
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('users', 'company_permission_template_id')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropIndex('users_company_permission_template_id_index');
                $table->dropColumn('company_permission_template_id');
            });
        }
    }
};
